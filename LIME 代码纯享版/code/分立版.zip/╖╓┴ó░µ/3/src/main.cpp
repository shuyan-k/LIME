#include "LIME.h"

int main()
{

    LIME lime;

    Mat frame, re;

    frame = imread("moon.bmp");
    Gt gt;
    gt.st();

    re = lime.run(frame);

    gt.et();
    gt.show("all");

    imwrite("out.jpg", re);

    return 0;
}
