#include "Gt.h"
#include <thread>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;
/* * 方法3 多核 */
class LIME_3_d
{
public:
    thread th1, th2;
    Mat img, Wv, Wh;
    LIME_3_d() {}
    Mat maxMAT(cv::Mat &input)
    {
        Gt gt;
        gt.st();

        Mat output(input.size(), CV_32FC1);
        uchar temp;
        for (int i = 0; i < input.size().height; i++)
        {
            for (int j = 0; j < input.size().width; j++)
            {
                temp = fmax(input.at<Vec3f>(i, j)[0], input.at<Vec3f>(i, j)[1]);
                output.at<float>(i, j) = fmax(input.at<Vec3f>(i, j)[2], temp);
            }
        }

        gt.et();
        gt.show("max");
        return output;
    }
    Mat Repeat(Mat &m)
    {
        Gt gt;
        gt.st();
        int he = m.size().height;
        int wi = m.size().width;
        Mat R(he, wi, CV_32FC3);
        for (int i = 0; i < he; i++)
        {
            for (int j = 0; j < wi; j++)
            {
                R.at<Vec3f>(i, j)[0] = m.at<float>(i, j);
                R.at<Vec3f>(i, j)[1] = m.at<float>(i, j);
                R.at<Vec3f>(i, j)[2] = m.at<float>(i, j);
            }
        }
        gt.et();
        gt.show("repeat");
        return R;
    }
    void get_wx()
    {
        Gt gt;
        gt.st();
        Mat grad_x;
        Scharr(img, grad_x, -1, 1, 0);
        Mat wh;
        wh = 1 / (cv::abs(grad_x) + 1);
        gt.et();
        gt.show("wx");
        this->Wh = wh;
    }
    void get_wy()
    {
        Gt gt;
        gt.st();
        Mat grad_y;
        Scharr(img, grad_y, -1, 0, 1);
        Mat wv;
        wv = 1 / (cv::abs(grad_y) + 1);
        gt.et();
        gt.show("wy");
        this->Wv = wv;
    }
    Mat get_t(Mat &t)
    {
        int he = t.size().height;
        int wi = t.size().width;

        this->th1.join();
        this->th2.join();

        Mat re = Wv + Wh;
        cv::Mat I = cv::Mat::ones(he, wi, CV_32F);
        re = I + re;
        re = re + img;

        re = re / 255;
        return re;
    }
    Mat run(cv::Mat &img1)
    {
        Gt gt;
        gt.st();

        img1.convertTo(img1, CV_32FC3);
        this->img = maxMAT(img1);

        this->th1 = std::thread(&LIME_3_d::get_wx, this);
        this->th2 = std::thread(&LIME_3_d::get_wy, this);

        Mat re = get_t(this->img);

        gt.et();
        gt.show("run");
        cv::pow(re, 0.6, re);
        Mat I_out = Repeat(re);

        Mat Re = img1 / (I_out);

        return Re / 255;
    }
};

int main()
{

    Gt gt;

    Mat img = imread("moon.bmp", 1);

    gt.st();
    img.convertTo(img, CV_32FC3);

    LIME_3_d lime;
    Mat r = lime.run(img);

    gt.et();
    gt.show("all");

    imwrite("out.jpg", r * 255);

    return 0;
}
