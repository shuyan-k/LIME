#include "sy.h"
#pragma once
class LIMEclass
{
public:
    Mat L;//原图
    Mat _T;//初始估计照度图
    Mat Dv, Dh;//托普勒兹矩阵
    Mat DTD;
    Mat W, Wv, Wh;//权重矩阵
    Mat X;//X矩阵

    int row, col;
    double iterations, alpha, rho, gamma, strategy, exact;


    //LIME类型构造函数
    LIMEclass(int iterations1, double alpha1, double rho1, double gamma1, double strategy1, bool exact1){
        iterations = iterations1; //循环次数
        alpha = alpha1; //α
        rho = rho1; //ρ
        gamma = gamma1; //γ
        strategy = strategy1; 
        exact = exact1;
        col = 0;
        row = 0;
    }

    //加载图片
    void load(Mat img) {
        L = img;
        row = L.size().height;
        col = L.size().width;

        Mat temp = maxMAT(L);

        _T = temp;
        Dv = create_Dv(row);   //生成row阶Toeplitz 矩阵
        Dh = create_Dh(col);  //生成col阶Toeplitz 矩阵
        get_DTD();
        W = Strategy();
    }

    //获得DTD矩阵
    void get_DTD(){
        Mat dx = Mat::zeros(row, col, CV_64FC1);
        Mat dy = Mat::zeros(row, col, CV_64FC1);

        dx.at<double>(1, 0) = 1;
        dx.at<double>(1, 1) = -1;
        dy.at<double>(0, 1) = 1;
        dy.at<double>(1, 1) = -1;

        Mat dxf = fft2D(dx);
        Mat dyf = fft2D(dy);


        Mat DTD1, DTD2;

        cv::mulSpectrums(dxf, dxf, DTD1, 0, true);
        cv::mulSpectrums(dyf, dyf, DTD2, 0, true);

        DTD = DTD1 + DTD2;
    }

    //获得权重矩阵 返回W
    Mat Strategy() {
        if (strategy == 2) {
            Mat c1, c2;
            cv::gemm(Dv, (_T / 255), 1, Mat(), 0, c1);
            cv::gemm((_T / 255), Dh, 1, Mat(), 0, c2);
            Mat Wv = 1.0 / (cv::abs(c1) + 1);
            Mat Wh = 1.0 / (cv::abs(c2) + 1);
            
            Mat res(row * 2, col, CV_64FC1);
            cv::vconcat(Wv, Wh, res);
            return res;
        }
        else {
            Mat res = Mat::zeros(row * 2, col, CV_64FC1);
            return res;
        }
    }

    //T问题迭代函数
    Mat T_sub(Mat G1, Mat Z1, double miu1) {
        Mat Xv, Xh;//储存分割后的矩阵
        Mat Re;//返回值

        X = G1 - Z1 / miu1;
        Xv = X(Rect(0, 0, X.cols, row));
        Xh = X(Rect(0, row, X.cols, row));


        Mat c1, c2;
        cv::gemm(Dv, Xv, 1, Mat(), 0, c1);
        cv::gemm(Xh, Dh, 1, Mat(), 0, c2);

        Mat term1 = 2.0 * _T;
        Mat term2 = miu1 * (c1 + c2);
        Mat res = (term1 + term2) / 255;


        cv::Mat numerator_fft = fft2D(res);


        cv::Mat miu1_mat = cv::Mat::ones(DTD.rows, DTD.cols, DTD.type()) * miu1;
        cv::Mat denominator = DTD.mul(miu1_mat) + 2;


        // 计算n/d
        //Mat k = numerator_fft / denominator;
        Mat k(row, col, CV_32FC2);
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                double den = denominator.at<std::complex<float>>(i, j).real();
                k.at<Vec2f>(i, j) = numerator_fft.at<Vec2f>(i, j) / den;
            }
        }

        
        // IFFT2操作
        cv::dft(k, k, DFT_INVERSE | DFT_SCALE);    // 进行IFFT2操作

        // 提取实部
        Mat T(row, col, CV_32FC1);
        Mat channels[2];
        split(k, channels);
        Mat T_real1(channels[0]);   // 提取实部
        T_real1.convertTo(T, CV_32FC1);

        rescale_intensity(T, T, 0, 1, 0.001, 1);
        Re = T;

        return Re;
    }


    // G 问题迭代函数
    Mat G_sub(Mat T_mx1, Mat Z1, double miu1, Mat W1) {
        Mat temp, temp1, temp3, Re, epsilon;
        epsilon = alpha * W1 / miu1;

        cv::gemm(Dv, T_mx1, 1, Mat(), 0, temp);
        cv::gemm(T_mx1, Dh, 1, Mat(), 0, temp1);

        cv::vconcat(temp, temp1, temp3);
        temp = temp3 + Z1 / miu1;
        
        cv::Mat temp_abs = cv::abs(temp);
        cv::Mat signMat = cv::Mat::ones(temp.size(), temp.type());
        
        cv::Mat mask_positive = (temp > 0);
        cv::Mat mask_negative = (temp < 0);
        signMat.setTo(1, mask_positive);
        signMat.setTo(-1, mask_negative);
        signMat.setTo(0, (temp_abs < FLT_EPSILON));

        cv::Mat abs_temp = cv::abs(temp);
        cv::Mat diff = abs_temp - epsilon;
        cv::Mat max_mat = cv::Mat::zeros(diff.size(), diff.type());
        for (int i = 0; i < diff.size().height; i++) {
            for (int j = 0; j < diff.size().width; j++) {
                if (diff.at<double>(i, j) > 0) {
                    max_mat.at<double>(i, j) = diff.at<double>(i, j);
                }
            }
        }  
        Re = signMat.mul(max_mat);

        return Re;
    }

    //Z 问题迭代函数
    Mat Z_sub(Mat T_mx1, Mat G1, Mat Z1, double miu1) {
        Mat temp1, temp2, temp3, Re;
        cv::gemm(Dv, T_mx1, 1, Mat(), 0, temp1);
        cv::gemm(T_mx1, Dh, 1, Mat(), 0, temp2);
        cv::vconcat(temp1, temp2, temp3);
        temp3 = temp3 - G1;
        Re = Z1 + miu1 * temp3;
        return Re;
    }

    //miu 的迭代，T的分问题
    double miu_sub(double miu1) {
        double Re;
        Re = miu1 * rho;
        return Re; //rho rou
    }

    //LIME计算
    Mat run() {
        Mat T;
        double miu;
        Mat Re(L.size().height, L.size().width, CV_64FC3);
        Mat T_mx, G, Z, Re_mx;
        if (exact) {

            T_mx = Mat::zeros(row, col, CV_64FC1);
            G = Mat::zeros(row * 2, col, CV_64FC1);
            Z = Mat::zeros(row * 2, col, CV_64FC1);
            miu = 1;
            for (int i = 0; i < iterations; i++) {
                T_mx = T_sub(G, Z, miu);
                G = G_sub(T_mx, Z, miu, W);
                Z = Z_sub(T_mx, G, Z, miu);
                miu = miu_sub(miu);
            }
            
            cv::pow(T_mx, gamma, T_mx);
            
            T = Repeat(T_mx);
            L.convertTo(L, CV_64FC3);

            imwrite("T_3.jpg",T*255);
            Re = L / T;
            
            rescale_intensity(Re, Re, 0.001, 1, 0, 1);
            return Re;
        }
        else {
            return Re;
        }
        return Re;
    }

};

