﻿#include "sy.h"


//最大值
Mat maxMAT(Mat &input) {
    Mat output(input.size(), CV_64F);
    double temp;
    for (int i = 0; i < input.size().height; i++) {
        for (int j = 0; j < input.size().width; j++) {
            temp = fmax((double)input.at<Vec3b>(i, j)[0], (double)input.at<Vec3b>(i, j)[1]);
            output.at<double>(i, j) = fmax((double)input.at<Vec3b>(i, j)[2], temp);
        }
    }
    return output;
}

//单通道转三通道
Mat Repeat(Mat &m) {
    int he = m.size().height;
    int wi = m.size().width;
    Mat R(he, wi, CV_64FC3);
    for (int i = 0; i < he; i++) {
        for (int j = 0; j < wi; j++) {
            R.at<Vec3d>(i, j)[0] = m.at<double>(i, j);
            R.at<Vec3d>(i, j)[1] = m.at<double>(i, j);
            R.at<Vec3d>(i, j)[2] = m.at<double>(i, j);
        }
    }
    return R;
}


/*
 * 对单通道图像进行2D FFT变换
 * @param input: 输入图像
 * @return: 傅里叶变换后的频域图像
 */
Mat fft2D(const Mat& input) {
    Mat complexImg;
    Mat planes[] = { Mat_<float>(input), Mat::zeros(input.size(), CV_32F) };
    cv::merge(planes, 2, complexImg);
    dft(complexImg, complexImg);
    return complexImg;
}

/*
 * 对单通道图像进行2D逆变换
 * @param input: 输入图像的频域表示
 * @return: 逆变换后的图像
 */
Mat ifft2D(const Mat& input) {
    Mat output;
    idft(input, output, DFT_SCALE | DFT_REAL_OUTPUT);
    return output;
}

Mat create_Dv(int row)
{
    Mat Dv = Mat::zeros(row, row, CV_64FC1);

    double* ptr = Dv.ptr<double>();
    for (int i = 0; i < row - 1; i++)
    {
        ptr[i * row + i] = -1;
        ptr[i * row + i + 1] = 1;
    }
    Dv.at<double>(row-1,row-1) = -1;
    return Dv;
}

Mat create_Dh(int col)
{
    Mat Dh = Mat::zeros(col, col, CV_64FC1);

    for (int i = 0; i < col; i++) {
        Dh.at<double>(i, i) = -1;
        if (i < col - 1) {
            Dh.at<double>(i + 1, i) = 1;
        }
    }


    return Dh;
}

void rescale_intensity(Mat& src, Mat& dst, double in_low, double in_high, double out_low, double out_high)
{
    if (src.channels() == 1)  // 灰度图像
    {
        double min = 0, max = 0;
        minMaxLoc(src, &min, &max);
        double alpha = (out_high - out_low) / (in_high - in_low);
        double beta = out_low - alpha * in_low;
        src.convertTo(dst, CV_64F);
        dst = alpha * (dst) + beta;
    }
    else if (src.channels() == 3)  // 彩色图像
    {
        vector<Mat> channels;
        split(src, channels);
        for (int i = 0; i < channels.size(); ++i)
        {
            Mat channel_rescaled;
            double min = 0, max = 0;
            minMaxLoc(channels[i], &min, &max);
            double alpha = (out_high - out_low) / (in_high - in_low);
            double beta = out_low - alpha * in_low;
            channels[i].convertTo(channel_rescaled, CV_64F);
            channel_rescaled = alpha * (channel_rescaled - min) + beta;
            channels[i].convertTo(channels[i], CV_8UC1);
        }
        cv::merge(channels, dst);
    }
}