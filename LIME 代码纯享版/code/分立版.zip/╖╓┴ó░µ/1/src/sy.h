/* LIME迭代算法中使用的函数 */
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/photo.hpp>
#include <opencv2/imgproc.hpp>
#include <math.h>
#include <cmath>
using namespace std;
using namespace cv;

Mat maxMAT(Mat& L); //获取三通道中的最大值为单通道图片输出
Mat fft2D(const Mat& input); // 快速傅里叶变化
Mat ifft2D(const Mat& input); // 逆傅里叶变化
Mat Repeat(Mat& m); //将单通道图片转为三通道
Mat create_Dv(int row); //特殊矩阵构造
Mat create_Dh(int col); //特殊矩阵构造
void rescale_intensity(Mat& src, Mat& dst, double in_low = 0, double in_high = 1, double out_low = 0, double out_high = 1);
// 归一化
