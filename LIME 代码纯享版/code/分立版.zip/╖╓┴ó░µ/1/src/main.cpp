﻿#include "LIMEclass.h"
#include <time.h>

//声明LIMEclass类并初始化 60次循环
LIMEclass limecore = LIMEclass(60, 0.15, 1.1, 0.8, 2, true);

int main(void) {
    clock_t start, end;
    double cpu_time_used;


    Mat frame = imread("moon.bmp", 1);
    start = clock();

    limecore.load(frame);
    Mat re = limecore.run();
    imwrite("tfor.jpg", re);


    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

    printf("程序运行时间为: %f 秒\n", cpu_time_used);

    imshow("re", re);
    waitKey(0);
    return 0;
}