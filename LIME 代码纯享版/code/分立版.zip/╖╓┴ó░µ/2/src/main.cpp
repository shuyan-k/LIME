#include "Gt.h"
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

/* * 方法2 单核 */
class LIME_2 {
public:
    Mat img,Wv,Wh;
    LIME_2(){}
    Mat maxMAT(cv::Mat &input) {
        Gt gt;
        gt.st();

        Mat output(input.size(), CV_32FC1);
        uchar temp;
        for (int i = 0; i < input.size().height; i++) {
            for (int j = 0; j < input.size().width; j++) {
                temp = fmax(input.at<Vec3f>(i, j)[0], input.at<Vec3f>(i, j)[1]);
                output.at<float>(i, j) = fmax(input.at<Vec3f>(i, j)[2], temp);
            }
        }

        gt.et();
        gt.show("max");
        return output;
    }
    Mat Repeat(Mat& m) {
        Gt gt;
        gt.st();
        int he = m.size().height;
        int wi = m.size().width;
        Mat R(he, wi, CV_32FC3);
        for (int i = 0; i < he; i++) {
            for (int j = 0; j < wi; j++) {
                R.at<Vec3f>(i, j)[0] = m.at<float>(i, j);
                R.at<Vec3f>(i, j)[1] = m.at<float>(i, j);
                R.at<Vec3f>(i, j)[2] = m.at<float>(i, j);
            }
        }
        gt.et();
        gt.show("repeat");
        return R;
    }
    void get_wx() {
        Gt gt;
        gt.st();

        Mat temp1, temp3;
        Scharr(img, temp1, CV_32FC1, 1, 0);

        temp3 = 1 / (abs(temp1) + 1);

        this->Wh = temp3 / (abs(temp1) + 1);

        gt.et();
        gt.show("wx");
    }
    void get_wy() {
        Gt gt;
        gt.st();
        Mat temp1, temp3;
        Scharr(img, temp1, CV_32FC1, 0, 1);

        temp3 = 1 / (abs(temp1) + 1);

        this->Wv = temp3 / (abs(temp1) + 1);

        gt.et();
        gt.show("wy");
    }
    Mat get_t(Mat &img1) {
        Gt gt;
        gt.st();

        this->img = maxMAT(img1);

        this->img.convertTo(this->img, CV_32FC1);


        get_wx();
        get_wy();

        Mat tx, ty;
        Scharr(this->img, tx, -1, 1, 0);
        Scharr(this->img, ty, -1, 0, 1);
        tx = tx.mul(tx);
        ty = ty.mul(ty);

        float alpha = 0.015;


        this->img = this->img.mul(this->img) + alpha * Wh.mul(tx) + alpha * Wv.mul(ty);
        pow(this->img, 0.5, this->img);


        pow(this->img, 0.6, this->img);
        normalize(this->img, this->img, 0, 255, NORM_MINMAX);
        this->img.convertTo(this->img, CV_32FC1);


        gt.et();
        gt.show("get_t");
        return this->img;
    }
    Mat run(cv::Mat &img1) {
        img1.convertTo(img1, CV_32FC3);
        Mat t = get_t(img1);
        Mat r = Repeat(t);
        img.convertTo(img, CV_32FC3);
        r = img1 / (r);
        return r;
    }
};

int main()
{

    Gt gt;

    Mat img = imread("moon.bmp", 1);

    gt.st();
    img.convertTo(img, CV_32FC3);

    LIME_2 lime;
    Mat r = lime.run(img);

    gt.et();
    gt.show("all");

    imwrite("out.jpg", r * 255);

    return 0;
}
