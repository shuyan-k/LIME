/* 全国大学生集成电路创新创业大赛 DJF */
此为LIME低照度处理算法第而版，采用加速求解方法
src 为源代码文件
build 文件夹，内置一张测试图片
CMakeLists.txt CMake配置文件。

使用方法：

cd build
cmake ..
make -j8
./2