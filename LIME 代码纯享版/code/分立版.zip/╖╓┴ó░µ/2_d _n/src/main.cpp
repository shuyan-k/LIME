#include "Gt.h"
#include <thread>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

/* * 方法2 多核+neon */
class LIME_2_d_n
{
public:
    thread th1, th2;
    Mat img, Wv, Wh;
    LIME_2_d_n() {}

    Mat max_neon(Mat &A, Mat &B, Mat &C)
    {

        Gt gt;
        gt.st();

        Mat D(A.size().height, A.size().width, CV_8UC1);
        for (int row = 0; row < A.size().height; row++)
        {
            for (int col = 0; col < A.size().width; col += 16)
            {
                uint8x16_t vec1 = vld1q_u8(&A.at<uchar>(row, col));
                uint8x16_t vec2 = vld1q_u8(&B.at<uchar>(row, col));
                uint8x16_t vec3 = vld1q_u8(&C.at<uchar>(row, col));

                uint8x16_t res_vec_1 = vmaxq_u8(vec1, vec2);
                uint8x16_t res_vec = vmaxq_u8(res_vec_1, vec3);
                vst1q_u8(&D.at<uchar>(row, col), res_vec);
            }
        }
        gt.et();
        gt.show("max");
        return D;
    }

    Mat repeat_neon(Mat &A)
    {

        Gt gt;
        gt.st();

        Mat B(A.size(), CV_32FC1);
        Mat C(A.size(), CV_32FC1);
        Mat R;
        vector<Mat> channels;
        for (int row = 0; row < A.size().height; row++)
        {
            for (int col = 0; col < A.size().width; col += 4)
            {
                float32x4_t vec1 = vld1q_f32(&A.at<float>(row, col));

                vst1q_f32(&B.at<float>(row, col), vec1);
                vst1q_f32(&C.at<float>(row, col), vec1);
            }
        }
        channels.push_back(A);
        channels.push_back(B);
        channels.push_back(C);
        merge(channels, R);

        gt.et();
        gt.show("repeat");
        return R;
    }

    void get_wx()
    {
        Gt gt;
        gt.st();

        Mat temp1, temp3;
        Scharr(this->img, temp1, CV_32FC1, 1, 0);

        temp3 = 1 / (abs(temp1) + 1);

        this->Wh = temp3 / (abs(temp1) + 1);

        gt.et();
        gt.show("wx");
    }
    void get_wy()
    {
        Gt gt;
        gt.st();
        Mat temp1, temp3;
        Scharr(this->img, temp1, CV_32FC1, 0, 1);

        temp3 = 1 / (abs(temp1) + 1);

        this->Wv = temp3 / (abs(temp1) + 1);

        gt.et();
        gt.show("wy");
    }
    Mat get_t(Mat &img1)
    {
        Gt gt;
        gt.st();

        img1.convertTo(img1, CV_8UC3);
        vector<Mat> channels;
        split(img1, channels);

        Mat R = channels[0];
        Mat G = channels[1];
        Mat B = channels[2];

        this->img = max_neon(R, G, B);

        this->img.convertTo(this->img, CV_32FC1);

        this->th1 = std::thread(&LIME_2_d_n::get_wx, this);
        this->th2 = std::thread(&LIME_2_d_n::get_wy, this);

        this->th1.join();
        this->th2.join();

        Mat tx, ty;
        Scharr(this->img, tx, -1, 1, 0);
        Scharr(this->img, ty, -1, 0, 1);
        tx = tx.mul(tx);
        ty = ty.mul(ty);

        float alpha = 0.015;

        this->img = this->img.mul(this->img) + alpha * Wh.mul(tx) + alpha * Wv.mul(ty);
        pow(this->img, 0.5, this->img);

        pow(this->img, 0.6, this->img);
        normalize(this->img, this->img, 0, 255, NORM_MINMAX);
        this->img.convertTo(this->img, CV_32FC1);

        gt.et();
        gt.show("get_t");
        return this->img;
    }
    Mat run(cv::Mat &img1)
    {

        Mat t = get_t(img1);
        Mat r = repeat_neon(t);

        img1.convertTo(img1, CV_32FC3);
        r = img1 / (r);
        return r;
    }
};

int main()
{

    Gt gt;

    Mat img = imread("moon.bmp", 1);

    gt.st();
    img.convertTo(img, CV_32FC3);

    LIME_2_d_n lime;

    Mat img_out = lime.run(img);

    gt.et();
    gt.show("all");

    imwrite("out.jpg", img_out*255);

    return 0;
}
