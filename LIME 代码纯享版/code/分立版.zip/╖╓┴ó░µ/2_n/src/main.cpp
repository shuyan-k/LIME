#include "Gt.h"
#include <opencv2/opencv.hpp>
#include <opencv2/photo.hpp>
#include <arm_neon.h>

using namespace cv;
using namespace std;
Mat max_neon(Mat &A, Mat &B, Mat &C){

    Gt gt;
    gt.st();


    //neon重写的照度图初始估计函数
    Mat D(A.size().height, A.size().width, CV_8UC1);
    for (int row = 0; row < A.size().height ; row++){
        for (int col = 0; col < A.size().width; col+=16){
            uint8x16_t vec1 = vld1q_u8(&A.at<uchar>(row,col));
            uint8x16_t vec2 = vld1q_u8(&B.at<uchar>(row,col));
            uint8x16_t vec3 = vld1q_u8(&C.at<uchar>(row,col));

            uint8x16_t res_vec_1 = vmaxq_u8(vec1, vec2);
            uint8x16_t res_vec   = vmaxq_u8(res_vec_1, vec3);
            vst1q_u8(&D.at<uchar>(row,col), res_vec);
        }
    }
    gt.et();
    gt.show("max");
    return D;
}

//neon重写的通道转换函数
Mat repeat_neon(Mat &A){

    Gt gt;
    gt.st();

    Mat B(A.size(),CV_32FC1);
    Mat C(A.size(),CV_32FC1);
    Mat R;
    vector<Mat> channels;
    for(int row = 0; row < A.size().height; row++){
        for(int col = 0; col < A.size().width; col+=4){
            float32x4_t vec1 = vld1q_f32(&A.at<float>(row,col));

            vst1q_f32(&B.at<float>(row,col),vec1);
            vst1q_f32(&C.at<float>(row,col),vec1);
        }
    }
    channels.push_back(A);
    channels.push_back(B);
    channels.push_back(C);
    merge(channels,R);

    gt.et();
    gt.show("repeat");
    return R;

}


Mat get_wx(Mat &img) {
    Gt gt;
    gt.st();

    Mat wx, temp1, temp3;
    Scharr(img, temp1, CV_32FC1, 1, 0);

    temp3 = 1 / (abs(temp1) + 1);

    wx = temp3 / (abs(temp1) + 1);

    gt.et();
    gt.show("wx");
    return wx;
}

Mat get_wy(Mat &img) {
    Gt gt;
    gt.st();
    Mat wy, temp1, temp3;
    Scharr(img, temp1, CV_32FC1, 0, 1);

    temp3 = 1 / (abs(temp1) + 1);

    wy = temp3 / (abs(temp1) + 1);

    gt.et();
    gt.show("wy");
    return wy;
}

Mat get_t(Mat &img){
    Gt gt;
    gt.st();

    vector<Mat> channels;
    split(img,channels);
        
    Mat R = channels[0];
    Mat G = channels[1];
    Mat B = channels[2];
        
    Mat t = max_neon(R,G,B);

    t.convertTo(t,CV_32FC1);
    Mat wx = get_wx(t);
    Mat wy = get_wy(t);

    Mat tx, ty;
    Scharr(t, tx, -1, 1, 0);
    Scharr(t, ty, -1, 0, 1);
    tx = tx.mul(tx);
    ty = ty.mul(ty);

    double alpha = 0.015;
    t = t.mul(t) + alpha * wx.mul(tx) + alpha * wy.mul(ty);

    t.convertTo(t, CV_64FC1);
    pow(t, 0.5, t);

    gt.et();
    gt.show("get_t");


    return t;
}

int main() {

    Mat img = imread("moon.bmp", 1);
    
    Gt gt;
    gt.st();

    img.convertTo(img, CV_8UC3);

    Mat t = get_t(img);
    

    pow(t, 0.6, t);

    normalize(t, t, 0, 255, NORM_MINMAX);
    t.convertTo(t, CV_32FC1);

    /*
    vector<Mat> channels = {t, t, t};
    Mat r;
    merge(channels, r);
    */

    Mat r = repeat_neon(t);
    img.convertTo(img,CV_32FC3);
    r = img / (r);

    gt.et();
    gt.show("all");

    imwrite("out.jpg", r*255);




    return 0;
}
